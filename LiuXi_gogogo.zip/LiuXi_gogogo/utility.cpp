#include "utility.h"

utility::utility()
{

}
